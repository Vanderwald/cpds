const DocTypes = {
  PORT: "SCHIPMENT",
  SCHIPMENT: "SCHIPMENT",
  SCHIP: "SCHIPMENT",
  CARGO: "SCHIPMENT"
};

module.exports = DocTypes;
